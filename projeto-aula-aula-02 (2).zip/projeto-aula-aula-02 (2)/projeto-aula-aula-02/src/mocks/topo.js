const topo = {
    boasVindas: "Olá, Nat!",
    legenda: "Encontre os melhores produtores.",
}

export default topo;