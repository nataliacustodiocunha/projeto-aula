const topo = {
    boasVindas: "Olá, Senhores!",
    legenda: "Encontre os melhores produtores.",
}

export default topo;